﻿//modifier_eul_cyclone
namespace SfEulCombo
{
    internal static class Program
    {
        private static Initialization ShadowFiend { get; set; }

        private static void Main()
        {
            ShadowFiend = new Initialization();
        }
    }
}