namespace Techies_Annihilation.BombFolder
{
    public class Enums
    {
        public enum BombStatus
        {
            WillDetonate = 30,
            Idle = 22
        }
    }
}