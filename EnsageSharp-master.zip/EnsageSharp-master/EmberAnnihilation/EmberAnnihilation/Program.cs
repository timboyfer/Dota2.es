﻿namespace EmberAnnihilation
{
    internal class Program
    {
        private static void Main()
        {

        }
    }
}
