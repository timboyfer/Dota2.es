using System.Threading.Tasks;

namespace ArcAnnihilation.Units.behaviour.Abilities
{
    internal class CanNotUseAbilties : ICanUseAbilties
    {
        public async Task UseAbilities(UnitBase myBase)
        {
        }
    }
}