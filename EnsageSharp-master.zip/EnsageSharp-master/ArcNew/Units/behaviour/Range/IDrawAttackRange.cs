﻿namespace ArcAnnihilation.Units.behaviour.Range
{
    public interface IDrawAttackRange
    {
    }

    public class DrawAttackRange : IDrawAttackRange
    {
    }

    public class DontDrawAttackRange : IDrawAttackRange
    {
    }
}