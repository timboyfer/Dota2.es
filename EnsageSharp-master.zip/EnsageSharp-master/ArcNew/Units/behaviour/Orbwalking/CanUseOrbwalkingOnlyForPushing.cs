namespace ArcAnnihilation.Units.behaviour.Orbwalking
{
    internal class CanUseOrbwalkingOnlyForPushing : ICanUseOrbwalking
    {
    }
}