﻿namespace ArcAnnihilation.Units.behaviour.Orbwalking
{
    public interface ICanUseOrbwalking
    {
    }
}