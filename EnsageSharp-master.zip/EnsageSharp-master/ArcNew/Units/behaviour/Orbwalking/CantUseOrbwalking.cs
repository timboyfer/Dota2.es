namespace ArcAnnihilation.Units.behaviour.Orbwalking
{
    internal class CantUseOrbwalking : ICanUseOrbwalking
    {
    }
}