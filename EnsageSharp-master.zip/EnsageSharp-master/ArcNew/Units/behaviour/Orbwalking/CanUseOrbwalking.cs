namespace ArcAnnihilation.Units.behaviour.Orbwalking
{
    internal class CanUseOrbwalking : ICanUseOrbwalking
    {
    }
}