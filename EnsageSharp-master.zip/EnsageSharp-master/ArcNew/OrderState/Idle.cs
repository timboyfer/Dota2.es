namespace ArcAnnihilation.OrderState
{
    public class Idle : Order
    {
        public override void Execute()
        {
        }
    }
}