﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("BirjaMemov")]
[assembly: ComVisible(false)]
[assembly: Guid("8b7c218e-a9c8-4210-a23e-112b095023a0")]