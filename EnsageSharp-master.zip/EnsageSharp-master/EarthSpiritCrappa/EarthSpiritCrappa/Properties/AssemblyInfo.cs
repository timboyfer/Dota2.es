﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("EarthSpiritCrappa")]
[assembly: ComVisible(false)]
[assembly: Guid("0598bc65-a6e9-43f4-bd9d-7eb1f4b90bc4")]