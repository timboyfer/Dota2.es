using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Ensage;
using Ensage.Abilities;
using Ensage.Common.Objects;
using Ensage.SDK.Extensions;
using Ensage.SDK.Helpers;
using log4net;
using PlaySharp.Toolkit.Logging;

namespace OverlayInformation
{
    public class Holder : IDisposable
    {
        public List<AbilityHolder> Holders;

        public Holder()
        {
            Holders = new List<AbilityHolder>();
            UpdateManager.Subscribe(Flush, 5000);
        }

        public void Dispose()
        {
            UpdateManager.Unsubscribe(Flush);
        }

        private void Flush()
        {
            var temp = Holders.Where(x => x.IsValid);
            Holders = temp.ToList();
        }

        public AbilityHolder GetOrCreate(Ability ability)
        {
            var find = Holders.Find(x => x.IsValid && x.Ability.Equals(ability));
            if (find != null) return find;
            find = new AbilityHolder(ability);
            Holders.Add(find);
            return find;
        }
    }

    public class AbilityHolder
    {
        private static readonly ILog Log = AssemblyLogs.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        public Ability Ability;
        public AbilityState AbilityState;
        public float Cooldown;
        public uint Cost;
        public uint Handle;
        public AbilityId Id;
        public bool IsHidden;
        public bool IsUltimate;
        public Item Item;
        public Hero Owner;
        public DotaTexture Texture;

        public AbilityHolder(Ability ability)
        {
            Ability = ability;
            Handle = ability.Handle;
            Name = ability.Name;
            MaximumLevel = Ability.MaximumLevel;
            Owner = (Hero) ability.Owner;
            Id = Ability.Id;
            AbilityState = ability.AbilityState;
            Texture = Ability is Item
                ? Textures.GetItemTexture(ability.Name)
                : Textures.GetSpellTexture(ability.Name);
            Cooldown = Ability.Cooldown;
            IsUltimate = ability.AbilityType == AbilityType.Ultimate;
            IsHidden = ability.IsHidden;
            AbilitySlot = ability.AbilitySlot;
            Item = ability as Item;
            if (Item != null) Cost = Item.Cost;
            UpdateManager.BeginInvoke(async () =>
            {
                while (ability.IsValid)
                {
                    AbilityState = ability.AbilityState;
                    Cooldown = Ability.Cooldown;
                    IsHidden = ability.IsHidden;
                    AbilitySlot = ability.AbilitySlot;
                    await Task.Delay(300);
                }

                //Log.Debug($"[{Owner.Name}] end for -> {Id}");
            });
        }

        public bool IsValid => Ability != null && Ability.IsValid;
        public int MaximumLevel { get; set; }
        public AbilitySlot AbilitySlot { get; set; }
        public string Name { get; set; }
    }

    public class CourContainer : IDisposable
    {
        public CourContainer(Courier cour, bool isAlly, OverlayInformation main)
        {
            Cour = cour;
            IsAlly = isAlly;
            Main = main;
            Items = new List<Item>();
            UpdateManager.Subscribe(UpdateItems, 500);
            UpdateManager.Subscribe(FlushChecker, 1000);
        }

        public Courier Cour { get; }
        public bool IsAlly { get; }
        public OverlayInformation Main { get; }

        public List<Item> Items { get; set; }

        public void Dispose()
        {
            UpdateManager.Unsubscribe(UpdateItems);
            UpdateManager.Unsubscribe(FlushChecker);
        }

        private void FlushChecker()
        {
            if (Cour == null || !Cour.IsValid) Dispose();
        }

        private void UpdateItems()
        {
            Items = Cour.Inventory.Items.ToList();
        }
    }

    public class HeroContainer
    {
        public static string GamePath = Game.GamePath;
        private static readonly ILog Log = AssemblyLogs.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        private static readonly List<AbilityId> DangeItemList = new List<AbilityId>
        {
            AbilityId.item_blink,
            AbilityId.item_gem,
            AbilityId.item_silver_edge,
            AbilityId.item_sheepstick,
            AbilityId.item_orchid,
            AbilityId.item_bloodthorn,
            AbilityId.item_black_king_bar,
            AbilityId.item_glimmer_cape,
            AbilityId.item_invis_sword
        };

        private static readonly List<AbilityId> InvisBreakerList = new List<AbilityId>
        {
            AbilityId.item_gem,
            AbilityId.item_dust,
            AbilityId.item_ward_sentry,
            AbilityId.item_ward_dispenser
        };

        public List<AbilityHolder> Abilities2;
        public bool AghanimState;
        public List<AbilityHolder> DangItems;
        public bool DontDraw;
        public float Health;
        public Holder HolderHelper;
        public List<AbilityHolder> InvisBreakerItems;
        public bool IsVisible;
        public List<AbilityHolder> Items;
        public float LastTimeUnderVision;
        public float Mana;
        public float MaxHealth;
        public float MaxMana;
        public uint Networth;

        //private readonly InventoryManager _manager;
        public float TimeInFog;

        //public Ability Ultimate;
        public AbilityHolder Ultimate;

        public HeroContainer(Hero hero, bool isAlly, OverlayInformation main)
        {
            var itemString = hero.HeroId.ToString().Remove(0, 14);
            main.Context.Value.TextureManager.LoadHeroFromDota(hero.HeroId);
            main.Context.Value.TextureManager.LoadFromFile(hero.HeroId.ToString(),
                $@"{GamePath}\game\dota\materials\ensage_ui\miniheroes\png\{itemString}.png");
            /*Log.Warn($"Texture Name: {itemString}");
            Log.Warn($"GamePath: {$@"{GamePath}\game\dota\materials\ensage_ui\miniheroes\png\{itemString}.png"}");*/
            //$@"resource\flash3\images\heroes\miniheroes\{hero.HeroId}.png");
            Name = hero.Name;
            Id = hero.Player == null ? 0 : hero.Player.Id;
            HolderHelper = new Holder();
            IsAlly = isAlly;
            Main = main;
            IsOwner = hero.Equals(ObjectManager.LocalHero);
            Hero = hero;
            //Ultimate = hero.Spellbook.Spells.First(x => x.AbilityType == AbilityType.Ultimate);
            LastTimeUnderVision = Game.RawGameTime;
            Items = new List<AbilityHolder>();
            DangItems = new List<AbilityHolder>();
            InvisBreakerItems = new List<AbilityHolder>();
            Abilities2 = new List<AbilityHolder>();
            foreach (var ability in GetAllAbilities)
            {
                var holder = HolderHelper.GetOrCreate(ability); //new AbilityHolder(ability);
                Abilities2.Add(holder);
                if (holder.IsUltimate)
                    Ultimate = holder;
                Log.Info($"{ability.Name} -> {(ability.AbilityType == AbilityType.Basic ? "basic" : "ultimate")}");
            }

            HeroInventory = Hero.Inventory;
            /*_manager = new InventoryManager(new EnsageServiceContext(hero));
            //manager.CollectionChanged += ManagerOnCollectionChanged;
            _manager.CollectionChanged += (sender, args) =>
            {
                //Items.Clear();
                DangItems.Clear();
                Items = _manager.Inventory.Items.ToList();
                Networth = 0;
                var tmpAgh = hero.HasAghanimsScepter();
                
                if (!AghanimState && tmpAgh || AghanimState && !tmpAgh)
                {
                    RefreshAbilities();
                }
                AghanimState = tmpAgh;
                foreach (var item in Items)
                {
                    Networth += item.Cost;
                    try
                    {
                        if (DangeItemList.Contains(item.Id))
                            DangItems.Add(item);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("GEGE -> "+e);
                    }
                }
            };*/
            UpdateInfo();
            UpdateItems();
            UpdateManager.Subscribe(UpdateItems, 500);
            UpdateManager.Subscribe(UpdateInfo, 250);
            UpdateManager.Subscribe(FlushChecker, 1000);

            var dividedWeStand = hero.Spellbook.SpellR as DividedWeStand;
            if (dividedWeStand != null && hero.HeroId == HeroId.npc_dota_hero_meepo && dividedWeStand.UnitIndex > 0)
                DontDraw = true;

            HeroId = hero.HeroId;
            if (HeroId == HeroId.npc_dota_hero_rubick || HeroId == HeroId.npc_dota_hero_doom_bringer /* ||
                classId == ClassId.CDOTA_Unit_Hero_Invoker*/ || HeroId == HeroId.npc_dota_hero_morphling)
                UpdateManager.Subscribe(AbilityUpdater, 750);

            /*Main.Context.Value.AbilityDetector.AbilityCasted += (sender, args) =>
            {
                Game.PrintMessage(args.Ability.Ability.Name);
            };
            Main.Context.Value.AbilityDetector.AbilityCastStarted += (sender, args) =>
            {
                Game.PrintMessage(args.Ability.Ability.Name);
            };*/
        }

        public bool IsAlly { get; }
        public OverlayInformation Main { get; }
        public bool IsOwner { get; }
        public Hero Hero { get; }
        public Inventory HeroInventory { get; set; }
        public AbilityState AbilityState { get; set; }
        public string Name { get; set; }

        public List<Ability> GetAllAbilities => Hero.Spellbook.Spells.Where(
                x =>
                    x.Name != "generic_hidden"
                    && !x.Name.Contains("seasonal")
                    && !x.Name.Contains("high_five")
                    && (x.AbilityType == AbilityType.Basic || x.AbilityType == AbilityType.Ultimate))
            .ToList();

        public HeroId HeroId { get; set; }

        public int Id { get; set; }

        private void FlushChecker()
        {
            if (Hero == null || !Hero.IsValid)
            {
                if (Game.GameState == GameState.GameInProgress)
                {
                    var player = ObjectManager.GetPlayerById((uint) Id);
                    Log.Error(
                        $"CUSTOM FLUSH FOR {Name} id -> [{Id}] -> player -> [{(player != null ? player.Name : "null")}]");
                }

                Flush();
            }
            else if (Hero.IsIllusion && !Hero.HasModifier("modifier_morphling_replicate") && Hero.IsAlive &&
                     Hero.IsVisible)
            {
                Log.Error(
                    $"Flush cuz illusion {Name} id -> [{Id}]");
                Flush();
            }
        }

        private void UpdateInfo()
        {
            if (Hero == null || !Hero.IsValid)
                return;
            IsVisible = Hero.IsVisible;
            if (IsVisible)
            {
                LastTimeUnderVision = Game.RawGameTime;
            }
            else
            {
                TimeInFog = Game.RawGameTime - LastTimeUnderVision;
                return;
            }

            Health = Hero.Health;
            Mana = Hero.Mana;
            MaxHealth = Hero.MaximumHealth;
            MaxMana = Hero.MaximumMana;
            if (Ultimate != null && Ultimate.IsValid)
                AbilityState = Ultimate.AbilityState;
        }

        private void UpdateItems()
        {
            if (Hero == null || !Hero.IsValid)
                return;
            if (!Hero.IsAlive || !Hero.IsVisible)
                return;
            DangItems.Clear();
            InvisBreakerItems.Clear();
            Items = new List<AbilityHolder>();
            Networth = 0;
            foreach (var item in HeroInventory.Items)
            {
                var localHolder = HolderHelper.GetOrCreate(item);
                Items.Add(localHolder);
                Networth += item.Cost;
                if (Main.Config.HeroOverlay.ItemDangItems)
                {
                    if (DangeItemList.Contains(item.Id))
                        DangItems.Add(localHolder);
                }
                else if (Main.Config.HeroOverlay.ItemInvisBreakItems)
                {
                    if (InvisBreakerList.Contains(item.Id))
                        InvisBreakerItems.Add(localHolder);
                }
            }

            var tmpAgh = Hero.HasAghanimsScepter();

            if (!AghanimState && tmpAgh || AghanimState && !tmpAgh) RefreshAbilities2();
            AghanimState = tmpAgh;
        }

        private void AbilityUpdater()
        {
            //var needToRefresh = Abilities.Any(x => x == null || !x.IsValid || x.IsHidden);
            var needToRefresh = Abilities2.Any(x => x == null || !x.IsValid || x.IsHidden);
            if (needToRefresh) RefreshAbilities2();
        }

        /*private void ManagerOnCollectionChanged(object sender, NotifyCollectionChangedEventArgs args)
        {

            if (args.Action == NotifyCollectionChangedAction.Add)
            {
                foreach (InventoryItem iitem in args.NewItems)
                {
                    Networth += iitem.Item.Cost;
                    if (DangeItemList.Contains(iitem.Id))
                        DangItems.Add(iitem.Item);
                    Items.Add(iitem.Item);
                }
            }
            else if (args.Action == NotifyCollectionChangedAction.Remove)
            {
                foreach (InventoryItem iitem in args.OldItems)
                {
                    Networth -= iitem.Item.Cost;
                    if (DangeItemList.Contains(iitem.Id))
                        DangItems.Remove(iitem.Item);
                    Items.Remove(iitem.Item);
                }
            }
        }*/

        public void RefreshAbilities2()
        {
            var abilities =
                Hero.Spellbook.Spells.Where(
                    x =>
                        (x.AbilityType == AbilityType.Basic || x.AbilityType == AbilityType.Ultimate) &&
                        x.Name != "generic_hidden"
                        && !x.Name.Contains("seasonal")
                        && !x.Name.Contains("high_five") &&
                        Abilities2.Find(y => y.Handle == x.Handle) == null && !x.IsHidden);
            foreach (var ability in abilities)
            {
                Abilities2.Add(HolderHelper.GetOrCreate(ability));
                //Abilities2.Add(new AbilityHolder(ability));
                Log.Info($"added new ability -> {ability.Name} ({ability.Owner.Name})");
                //Game.PrintMessage($"added new ability -> {ability.Name} ({ability.Owner.Name})");
            }

            Abilities2.RemoveAll(x => !x.IsValid /* || x.IsHidden*/);
        }

        public void Flush()
        {
            //_manager.Deactivate();
            if (HeroId == HeroId.npc_dota_hero_rubick || HeroId == HeroId.npc_dota_hero_doom_bringer /* ||
                classId == ClassId.CDOTA_Unit_Hero_Invoker*/ || HeroId == HeroId.npc_dota_hero_morphling)
                UpdateManager.Unsubscribe(AbilityUpdater);

            UpdateManager.Unsubscribe(UpdateItems);
            UpdateManager.Unsubscribe(UpdateInfo);
            UpdateManager.Unsubscribe(FlushChecker);
            HolderHelper.Dispose();
        }
    }
}