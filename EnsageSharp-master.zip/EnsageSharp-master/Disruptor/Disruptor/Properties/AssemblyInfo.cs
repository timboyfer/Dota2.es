﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Disruptor")]
[assembly: ComVisible(false)]
[assembly: Guid("88cfd203-4f0d-4a70-a9c5-9ee6a6adae82")]