﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("MonkeyKingEulCombo")]
[assembly: ComVisible(false)]
[assembly: Guid("b364d32d-d9a1-4bde-a99a-6eb983ae613b")]