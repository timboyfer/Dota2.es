﻿using System;

namespace WindRunner_Annihilation.Logic
{
    public static class DrawShackleshot
    {
        public static void Draw(EventArgs args)
        {
            var target = ShackleshotCalculation.Target;

        }
    }
}