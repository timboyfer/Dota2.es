﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("InfinityBash")]
[assembly: ComVisible(false)]
[assembly: Guid("0c99fd90-3d2e-424c-a7e5-d80ed064af23")]