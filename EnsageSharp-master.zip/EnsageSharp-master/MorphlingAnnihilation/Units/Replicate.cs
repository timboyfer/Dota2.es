using Ensage;
using MorphlingAnnihilation.Interface;

namespace MorphlingAnnihilation.Units
{
    public class Replicate : StandartUnit
    {
        public Replicate(Hero me) : base(me)
        {

        }
    }
}